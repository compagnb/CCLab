#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
    ofBackground(200);
    ofSetVerticalSync(true);
    
	// listen on the given port
	cout << "listening for osc messages on port " << PORT << "\n";
	receiver.setup(PORT);

	current_msg_string = 0;
	mouseX = 0;
	mouseY = 0;
	mouseButtonState = "";
    
    //video variables
    
    frameByframe = false;
    
    // Uncomment this to show movies with alpha channels
	// fingerMovie.setPixelFormat(OF_PIXELS_RGBA);
    
	waveMovie.loadMovie("movies/waves.mov");
	//waveMovie.play();
    

	ofBackground(200);

}

//--------------------------------------------------------------
void testApp::update(){


    // check for waiting messages
	while( receiver.hasWaitingMessages() )
	{
		if(w == 0 || h == 0){
			w = ofGetWidth();
			h = ofGetHeight();
		}
		// get the next message
		ofxOscMessage m;
		float x,y;
		receiver.getNextMessage( &m );
		if (m.getAddress() == "/wii/1/accel/pry/1") { // roll rotating the remote
			roll = m.getArgAsFloat(0);
			
		} else if (m.getAddress() == "/wii/1/accel/pry/2") { // yaw left to right
			yaw = m.getArgAsFloat(0);
		}
		else if (m.getAddress() == "/wii/1/accel/pry/0") { // pitch up an down tilts
			pitch = m.getArgAsFloat(0);
			
		} else if (m.getAddress() == "/wii/1/accel/pry/3") { // accel acceleration
			accel = m.getArgAsFloat(0);
		}else if (m.getAddress() == "/wii/1/button/A") { // accel acceleration
			aBut = m.getArgAsFloat(0);
		}else if (m.getAddress() == "/wii/1/button/B") { // accel acceleration
			bBut = m.getArgAsFloat(0);
		}else if (aBut == 1){
            //frameByframe=!frameByframe;
           // waveMovie.setPaused(frameByframe);
        }else if(!frameByframe){
            //waveMovie.setSpeed(roll*5);
        }
        
        else
		{
			//cout << "unrecognized message: " << m.getAddress() << "\n";
            //cout << "unrecognized message: " << aBut << "\n";
            cout << "roll: " << roll << "\n";
		}
	}
    waveMovie.update();

}


//--------------------------------------------------------------
void testApp::draw(){
    
   // waveMovie.draw(0,0);

	
	//ofSetColor(200, 0, 200);
	//float radius = 50;
	//ofFill();
	//ofCircle(wiiX, wiiY, radius);
	ofCircle(roll *= ofGetWidth(), yaw *= ofGetHeight(),10);
	ofCircle(accel *= ofGetWidth(), pitch *= ofGetWidth(), 10);
    
    



}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){

}
